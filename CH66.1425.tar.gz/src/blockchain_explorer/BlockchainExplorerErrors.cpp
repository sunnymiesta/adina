#include "BlockchainExplorerErrors.h"

namespace CryptoNote {
namespace error {

BlockchainExplorerErrorCategory BlockchainExplorerErrorCategory::INSTANCE;

} //namespace error
} //namespace CryptoNote

