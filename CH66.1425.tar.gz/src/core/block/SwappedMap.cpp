#include "SwappedMap.h"

namespace {
  char suppressMSVCWarningLNK4221;
}
