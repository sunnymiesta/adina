#include <algorithm>
#include <cstdio>
#include <boost/foreach.hpp>
