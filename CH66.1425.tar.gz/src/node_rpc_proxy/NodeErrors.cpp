#include "NodeErrors.h"

namespace CryptoNote {
namespace error {

NodeErrorCategory NodeErrorCategory::INSTANCE;

}
}
